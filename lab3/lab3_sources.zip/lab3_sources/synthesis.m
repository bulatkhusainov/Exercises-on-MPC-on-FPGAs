% Perform synthesis, i.e. convert VHDL code into FPGA bitstream
cd protoip_project
ip_prototype_build('project_name','my_project0','board_name','zedboard');
cd ..